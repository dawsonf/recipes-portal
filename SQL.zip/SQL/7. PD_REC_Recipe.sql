CREATE PROCEDURE PD_REC_Recipe
(
  @rec_code INT
)
AS
/*
  Author: Naman Singh
  Date C: 2022-02-10
  Task  : Delete Recipe item
*/
BEGIN
  DELETE FROM 
    TM_REC_Recipe
  WHERE
    rec_code = @rec_code
END


