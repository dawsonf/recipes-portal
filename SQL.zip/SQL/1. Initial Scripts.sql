CREATE DATABASE RecipesDB
GO
USE RecipesDB

CREATE TABLE TR_GRP_Group
(
  grp_id SMALLINT PRIMARY KEY,
  grp_description VARCHAR(16) NOT NULL
)
GO

CREATE TABLE TM_USR_Users
(
  usr_code INT PRIMARY KEY IDENTITY(1,1),
  usr_user_name VARCHAR(15) UNIQUE NOT NULL,
  usr_password VARCHAR(15) /*VARBINARY(MAX)*/ NOT NULL,
  usr_first_name VARCHAR(15),
  usr_surname VARCHAR(15),
  usr_date_created DATETIME NOT NULL,
  grp_id SMALLINT NOT NULL REFERENCES TR_GRP_Group(grp_id),
  usr_active BIT NOT NULL 
)
CREATE NONCLUSTERED INDEX ix_id_grp ON TM_USR_Users(grp_id)
GO

CREATE TABLE TM_REC_Recipe
(
  rec_code INT PRIMARY KEY IDENTITY(1,1),
  rec_date_created DATETIME NOT NULL,
  rec_name VARCHAR(20) NOT NULL,
  rec_ingredients NVARCHAR(MAX),--store json list of ingredients object
  usr_code INT REFERENCES TM_USR_Users(usr_code),--author 
  rec_image NVARCHAR(MAX)
)
CREATE NONCLUSTERED INDEX ix_code_rec ON TM_REC_Recipe(usr_code)
GO

INSERT INTO TR_GRP_Group
(
  grp_id,
  grp_description
)
VALUES
(
  0,
  'Admin'
)

INSERT INTO TR_GRP_Group
(
  grp_id,
  grp_description
)
VALUES
(
  1,
  'User'
)

INSERT INTO TM_USR_Users
(
  usr_user_name,
  usr_password,
  usr_first_name,
  usr_surname,
  usr_date_created,
  grp_id,
  usr_active 
)
SELECT
  'admin',
  'p@ssw0rd',--CAST('p@ssw0rd' as VARBINARY(MAX)),
  'administrator',
  'administrator',
  GETDATE(),
  0,
  1

INSERT INTO TM_USR_Users
(
  usr_user_name,
  usr_password,
  usr_first_name,
  usr_surname,
  usr_date_created,
  grp_id,
  usr_active 
)
SELECT
  'user',
  'p@ssw0rd',--CAST('p@ssw0rd' as VARBINARY(MAX)),
  'John',
  'Doe',
  GETDATE(),
  1,
  1