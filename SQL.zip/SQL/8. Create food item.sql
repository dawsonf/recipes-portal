
declare @json NVARCHAR(MAX) = '[{"ingredient":"chicken"},{"ingredient":"gravy"}]'

EXEC  PI_REC_Recipe  'roasted-chicken', @json,1,null

GO

declare @json NVARCHAR(MAX) = '[{"ingredient":"salt"},{"ingredient":"pepper"},{"ingredient":"spices"}]'

EXEC  PI_REC_Recipe  'curry', @json,1,null

GO

declare @json NVARCHAR(MAX) = '[{"ingredient":"Yeast"},{"ingredient":"Wheat"},{"ingredient":"SomethingElse"}]'

EXEC  PI_REC_Recipe 'bread', @json,1,null

GO

declare @json NVARCHAR(MAX) = '[{"ingredient":"chicken"},{"ingredient":"lettuce"},{"ingredient":"salad dressing"}]'

EXEC  PI_REC_Recipe  'chicken-salad', @json,1,null


GO

declare @json NVARCHAR(MAX) = '[{"ingredient":"chicken"},{"ingredient":"lettuce"},{"ingredient":"salad dressing"}]'

EXEC  PI_REC_Recipe  'chicken-pie', @json,1,null


GO

declare @json NVARCHAR(MAX) = '[{"ingredient":"chicken"},{"ingredient":"lettuce"},{"ingredient":"salad dressing"}]'

EXEC  PI_REC_Recipe  'caesar-salad', @json,1,null


GO

declare @json NVARCHAR(MAX) = '[{"ingredient":"chicken"},{"ingredient":"lettuce"},{"ingredient":"salad dressing"}]'

EXEC  PI_REC_Recipe  'hot-dog', @json,1,null


GO

declare @json NVARCHAR(MAX) = '[{"ingredient":"chicken"},{"ingredient":"lettuce"},{"ingredient":"salad dressing"}]'

EXEC  PI_REC_Recipe  'round-pizza', @json,1,null

GO

--select * from TM_REC_Recipe