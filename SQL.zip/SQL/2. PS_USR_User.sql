CREATE PROCEDURE PS_USR_User
(
  @usr_user_name VARCHAR(15),
  @usr_password VARCHAR(15) /*VARBINARY(MAX)*/
)
AS
/*
  Author: Naman Singh
  Date C: 2022-02-10
  Task  : Return user record if there is a positive match
*/
BEGIN
  SELECT
    usr.usr_code[UserCode],
    usr.usr_user_name[Username],
    usr.usr_first_name[FirstName],
    usr.usr_surname[Surname],
    usr.grp_id[UserGroup]
  FROM
    TM_USR_Users usr WITH(NOLOCK)
  WHERE
    usr.usr_user_name = @usr_user_name and
	usr.usr_password = @usr_password and
	usr.usr_active = 1
END

--declare @password  varbinary(max) = CAST('p@ssw0rd' as varbinary(max))

--exec PS_USR_User 'admin', @password

--select * from TM_USR_Users